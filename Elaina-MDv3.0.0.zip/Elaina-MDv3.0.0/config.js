global.owner = ['60135461140']  
global.mods = ['60135461140'] 
global.prems = ['60135461140']
global.nameowner = 'Lawliet'
global.numberowner = '60135461140'
global.nomorown = '60135461140'
global.sgc = 'https://chat.whatsapp.com/I3wYl0QIklK0RaPNKkHbQQ'
global.namebot = '© Elaina-MD'
global.mail = 'kazumamyoc@gmail.com' 
global.gc = 'https://chat.whatsapp.com/I3wYl0QIklK0RaPNKkHbQQ'
global.fotomu = 'https://api.betabotz.eu.org/api/tools/get-upload?id=f/6ucgnnc1.jpg'
global.menu = 'https://api.betabotz.eu.org/api/tools/get-upload?id=f/6ucgnnc1.jpg' //image menu , but not work 
global.instagram = 'https://instagram.com/kazumamyoc'
global.wm = '© Elaina-MD 🍁'
global.wait = '_*Tunggu sedang di proses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With'
global.author = 'Lawliet'
global.maxwarn = '2' // Peringatan maksimum

//INI WAJIB DI ISI!//
global.lann = 'nurhasanah'
global.xzn = 'katz'
global.lol = 'bc131817e421982d74969fdb'
//Daftar terlebih dahulu https://api.betabotz.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.btc = 'dR8Lnw8b'
//Daftar https://api.botcahx.eu.org 

global.APIs = {   
  lann: 'https://api.betabotz.eu.org',
  lol: 'https://api.lolhuman.xyz',
  alya: 'https://api.alyachan.dev',
  btc: 'https://api.botcahx.eu.org',
  xzn: 'https://skizo.tech'
}
global.APIKeys = { 
  'https://api.betabotz.eu.org': 'nurhasanah',
  'https://api.alyachan.dev': 'OQtXCT',
  'https://skizo.tech': 'katz',
  'https://api.botcahx.eu.org': 'APIKEY'
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
