/**
* jangan ganti ya kakak kakak sekalian
* ini cuma buat ninggalin credit gw doang :)
* jangan dihilangin, boleh di tambahin 🐦
**/
let handler = async (_0x43d2f1, {
  conn: _0x33c87e
}) => {
  _0x43d2f1.reply("\n- Allah SWT \n- Lawliet\n- Akira\n- BOTCAHX\n- Kemii\n- Kalian semua yang telah menggunakan script ini.\n");
};
handler.help = ["tqto"];
handler.tags = ['info'];
handler.command = /^(tqto|team)$/i;
module.exports = handler;