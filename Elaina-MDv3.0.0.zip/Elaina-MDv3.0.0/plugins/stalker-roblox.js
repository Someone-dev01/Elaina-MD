const https = require("https");

const handler = async (m, { args }) => {
  if (args.length < 1) {
    return await m.reply("Harap memasukkan nama");
  }

  await m.reply(wait);
  https.get(`https://api-zenith.koyeb.app/api/stalker/roblox?apikey=zenkey&username=${args[0]}`, (res) => {
    let data = "";
    res.on("data", (chunk) => {
      data += chunk;
    });
    res.on("end", async () => {
      let json;
      try {
        json = JSON.parse(data);
      } catch (e) {
        throw e;
        return;
      }
      if (json.result && json.result.user) {
        const { name, displayName, id, created, description, hasVerifiedBadge, thumbnail } = json.result.user;
        const followers = json.result.followers && !json.result.followers.errors ? json.result.followers.count : "Tidak diketahui";
        const friends = json.result.friends ? json.result.friends.count : "Tidak diketahui";
        const robloxBadges = Array.isArray(json.result.robloxBadges) ? json.result.robloxBadges : [];
        const { reputation, discord, liked, theme, tier } = json.result.roproInfo || {};
        const groups = json.result.groups || [];
        const groupInfo = groups.length > 0 ? groups.map((group) => group.name).join(", ") : "Tidak ada grup";
        const badgesInfo = robloxBadges.length > 0
          ? robloxBadges.map((badge, index) => `${index + 1}. ${badge.name} - ${badge.description}`).join("\n")
          : "Tidak ada lencana";

        const caption = `*\`R O B L O X - S T A L K\`*
        
> Nama: ${displayName}
> ID: ${id}
> Dibuat: ${new Date(created).toLocaleString()}
> Pengikut: ${followers}
> Teman: ${friends}
> Gambar: ${thumbnail?.imageUrl || "Tidak ada gambar"}         
> Grup: ${groupInfo}
> Deskripsi: ${description || "Tidak ada deskripsi"}

*\`RoPro Info:\`*
- Reputasi: ${reputation || "Tidak ada"}
- Discord: ${discord || "Tidak terhubung"}
- Disukai: ${liked ? "Ya" : "Tidak"}
- Tema: ${theme || "Tidak ada tema"}
- Tier: ${tier || "none"}

*\`Lencana Roblox:\`*

${badgesInfo}
                           
*Ini adalah hasil pencarian untuk pengguna Roblox dengan nama "${displayName}". Semoga informasi ini membantu!*`;

        await m.reply(caption.trim());
      } else {
        await m.reply("Pengguna tidak ditemukan.");
      }
    });
  }).on("error", async () => {
    await m.reply("eror!");
  });
};

handler.help = handler.command = ["roblox"];
handler.tags = ["stalk"];

module.exports = handler;
