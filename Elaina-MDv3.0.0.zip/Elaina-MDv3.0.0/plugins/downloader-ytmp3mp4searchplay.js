const axios = require('axios');
const yts = require('yt-search');

/* 
TERIMAKASIH ATAS 

• DAFFA 
• SYAII
• SHENDY 
• PUTU
*/

const getVideoId = (url) => {
  const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/[^\/\n\s]+\/|(?:v|e(?:mbed)?)\/|[^v\r\s]+\/|user\/[^\/\n\s]+|embed\/|videoseries\?list=)|(?:youtu\.)?be(?:\.com)?\/(?:watch\?v=|v\/|u\/\w\/|embed\/|watch\?v%3D|watch\?v-|watch\/|v=)?)((\w|-){11}).*/;
  const match = url.match(regex);
  if (match) {
    return match[1];
  }
  throw new Error("Invalid YouTube URL");
};

const Ytdl = {
  search: async (query) => {
    try {
      const { videos } = await yts(query);
      return {
        status: true,
        creator: "@Bang_shenn",
        data: videos.map(video => ({
          title: video.title,
          url: `https://youtu.be/${video.videoId}`,
          img: video.image,
          author: {
            name: video.author.name,
            url: video.author.url,
          },
        })),
      };
    } catch (error) {
      return {
        status: false,
        msg: "Data tidak dapat ditemukan!",
        err: error.message,
      };
    }
  },

  mp3: async (url, { mp3 = '192' } = {}) => {
    try {
      const videoId = getVideoId(url);
      const videoData = (await yts(videoId)).videos[0];
      const data = new URLSearchParams({ videoid: videoId, downtype: 'mp3', vquality: mp3 });

      const response = await axios.post('https://api-cdn.saveservall.xyz/ajax-v2.php', data, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      });

      const mp3Link = response.data.url;
      return {
        status: true,
        creator: "@Bang_shenn",
        msg: "Success Download Content!",
        title: videoData.title,
        thumbnail: videoData.image,
        url: `https://youtu.be/${videoId}`,
        media: mp3Link,
      };

    } catch (error) {
      return {
        status: false,
        msg: "Gagal saat mengambil data!",
        err: error.message,
      };
    }
  },

  mp4: async (url, { mp4 = '480' } = {}) => {
    try {
      const videoId = getVideoId(url);
      const videoData = (await yts(videoId)).videos[0];
      const data = new URLSearchParams({ videoid: videoId, downtype: 'mp4', vquality: mp4 });

      const response = await axios.post('https://api-cdn.saveservall.xyz/ajax-v2.php', data, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      });

      const mp4Link = response.data.url;
      return {
        status: true,
        creator: "@Bang_shenn",
        msg: "Success Download Content!",
        title: videoData.title,
        thumbnail: videoData.image,
        url: `https://youtu.be/${videoId}`,
        media: mp4Link,
      };

    } catch (error) {
      return {
        status: false,
        msg: "Gagal saat mengambil data!",
        err: error.message,
      };
    }
  },

  play: async (query) => {
    try {
      let url = query;
      // If it's not a URL, search for it on YouTube
      if (!query.match(/^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)/)) {
        const searchResult = await Ytdl.search(query);
        if (!searchResult.status || searchResult.data.length === 0) throw new Error("No results found");
        url = searchResult.data[0].url; // Pick the top result
      }
      // Convert to MP3 and return result
      const mp3Result = await Ytdl.mp3(url);
      return mp3Result;
      
    } catch (error) {
      return {
        status: false,
        msg: "Gagal memainkan musik!",
        err: error.message,
      };
    }
  }
};

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh penggunaan: ${usedPrefix + command} <link atau judul YouTube>`;

  let result;
  if (command === 'ytmp3') {
    result = await Ytdl.mp3(text);
  } else if (command === 'ytmp4') {
    result = await Ytdl.mp4(text);
  } else if (command === 'play') {
    result = await Ytdl.play(text);
  } else {
    result = await Ytdl.search(text);
  }

  if (!result.status) throw result.msg;

  if (command === 'ytmp3' || command === 'play') {
    const doc = {
      audio: { url: result.media },
      mimetype: 'audio/mp4',
    };
    await conn.sendMessage(m.chat, doc, { quoted: m });
  } else if (command === 'ytmp4') {
    await conn.sendMessage(m.chat, { video: { url: result.media }, caption: result.title }, { quoted: m });
  } else {
    let searchResults = result.data.map((v, i) => `${i + 1}. *${v.title}*\n   Link: ${v.url}`).join('\n\n');
    await conn.sendMessage(m.chat, { text: searchResults }, { quoted: m });
  }
};

handler.help = ['ytmp3', 'ytmp4', 'ytsearch', 'play'];
handler.tags = ['downloader'];
handler.command = /^(ymp3|ymp4|yts|ytsearch|play)$/i;

module.exports = handler;