let handler = async (m, { conn, usedPrefix }) => {
let text = `*SELL SCRIPT Elaina-MD v3.0.0*
🏷️ Price : *Rp. 20.000* 

*Special Features & Benefit :*
- AI & AI Image
- Chat GPT (Turbo 3.5)
- Chat Ai (Character Ai)
- 39 Mini Games
- 60 Ai Features 
- 100 RPG Features
- Auto AI
- Leveling/Role
- Pinterest Slide
- Free Updates

_Minat ? chat_
wa.me/60135461140`
conn.sendFile(m.chat, 'https://pomf2.lain.la/f/oxjm3pr.jpg', '', text, m)
}
handler.help = ['sc', 'sourcecode']
handler.tags = ['info','main']
handler.command = /^(sc|sourcecode)$/i
handler.register = false

module.exports = handler