const fetch = require("node-fetch");
const Genius = require("genius-lyrics");
const axios = require("axios");
const cheerio = require("cheerio");

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Contoh Penggunaan: .lirik Somebody's Pleasure`;
  let key = "h6fTn1BYNjYi5VTszhyAFTcM3WWtk2E4hqrXCcutfObE4jVFnJ3LVyewHKIYTli7";
  let Client = new Genius.Client(key);
  let song = await Client.songs.search(text);
  let nothing = "Tidak diketahui!";
  
  try {
    let jenius = await song[0];
    let albert = `*Judul:* ${jenius.title ? jenius.title : nothing}
*Artis:* ${(await jenius.artist.name) ? await jenius.artist.name : nothing}

*Lyrics:*
${await getLyrics(jenius.url)}`;
    m.reply(albert);
  } catch {
    try {
      const resh = await getLirik(text);
      m.reply(`Title: ${resh.title}\n\nLyrics: ${resh.lyrics}`);
    } catch {
      try {
        const result = await findSongs(text);
        m.reply(`Title: ${result.title}\n\nLyrics: ${result.lyrics}`);
      } catch {
        throw `Maaf tidak di temukan lirik *${text}*`;
      }
    }
  }
};

handler.help = ["lirik"].map((v) => v + " <teks>");
handler.tags = ["internet"];
handler.command = /^(lirik|lyrics|lyric)$/i;
handler.limit = true;

module.exports = handler;

async function getLyrics(url) {
  const response = await fetch("https://files.xianqiao.wang/" + url);
  const html = await response.text();
  const $ = cheerio.load(html);
  let lyrics = "";
  $('div[class^="Lyrics__Container"]').each((i, elem) => {
    if ($(elem).text().length !== 0) {
      const snippet = $(elem)
        .html()
        .replace(/<br>/g, "\n")
        .replace(/<(?!\s*br\s*\/?)[^>]+>/gi, "");

      lyrics += $("<textarea/>").html(snippet).text().trim() + "\n\n";
    }
  });
  return lyrics;
}

async function findSongs(text) {
  try {
    const { data } = await axios.get(
      "https://songsear.ch/q/" + encodeURIComponent(text)
    );
    const $ = cheerio.load(data);
    const result = {
      title:
        $("div.results > div:nth-child(1) > .head > h3 > b").text() +
        " - " +
        $("div.results > div:nth-child(1) > .head > h2 > a").text(),
      album: $("div.results > div:nth-child(1) > .head > p").text(),
      number: $("div.results > div:nth-child(1) > .head > a")
        .attr("href")
        .split("/")[4],
      thumb: $("div.results > div:nth-child(1) > .head > a > img").attr("src"),
    };

    const { data: lyricData } = await axios.get(
      `https://songsear.ch/api/song/${result.number}?text_only=true`
    );
    const lyrics = lyricData.song.text_html
      .replace(/<br\/>/g, "\n")
      .replace(/&#x27;/g, "'");

    return {
      status: true,
      title: result.title,
      album: result.album,
      thumb: result.thumb,
      lyrics: lyrics,
    };
  } catch (err) {
    console.log(err);
    return {
      status: false,
      error: "Unknown error occurred",
    };
  }
}

async function getLirik(title) {
  try {
    const res = await fetch(
      `https://search.azlyrics.com/suggest.php?q=${encodeURIComponent(title)}`
    );

    if (!res.ok) {
      throw new Error(`Failed to fetch search results. Status: ${res.status}`);
    }

    const search = await res.json();

    if (!search || !search.songs || search.songs.length === 0) {
      throw new Error(`No songs found for "${title}"`);
    }

    const r = await fetch(search.songs[0].url);

    if (!r.ok) {
      throw new Error(`Failed to fetch lyrics. Status: ${r.status}`);
    }

    const htmlText = await r.text();
    const indexOfComment = htmlText.indexOf(
      "Usage of azlyrics.com content by any third-party lyrics provider is prohibited by our licensing agreement. Sorry about that."
    );
    const startIndex = htmlText.lastIndexOf("<div", indexOfComment);
    const endIndex = htmlText.indexOf("</div>", indexOfComment) + 6;
    const lyrics = htmlText
      .substring(startIndex, endIndex)
      .replace(/<!--[^>]*-->/g, "")
      .replace(/<br>/g, "")
      .replace(/<\/?div[^>]*>/g, "")
      .replace(/<\/?i[^>]*>/g, "")
      .trim();

    return {
      title: search.songs[0].autocomplete,
      lyrics: lyrics,
    };
  } catch (error) {
    throw new Error(`Failed to get lyrics for "${title}": ${error}`);
  }
}
